﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Xml;
using DataTier;
using LogicTier;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace PresentationTier
{
    public partial class MainWindow : Window
    {
        private Университет университет;
        private string selectedFilePath;

        public MainWindow()
        {
            InitializeComponent();
        }
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (myComboBox.SelectedItem != null)
            {
                var selectedItem = (System.Windows.Controls.ComboBoxItem)myComboBox.SelectedItem;
                MessageBox.Show($"Выбрано: {selectedItem.Content}");
            }
        }

        private void btn_open_file_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|JSON files (*.json)|*.json|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                selectedFilePath = openFileDialog.FileName;
                List<Преподаватель> преподаватели = new List<Преподаватель>();

                if (Path.GetExtension(selectedFilePath).ToLower() == ".json")
                {
                    string json = File.ReadAllText(selectedFilePath);
                    преподаватели = JsonConvert.DeserializeObject<List<Преподаватель>>(json);
                }
                else
                {
                    преподаватели = ВсеПреподаватели.ПолучитьВсеПреподавателиИзФайла(selectedFilePath);
                }

                if (преподаватели.Count == 0)
                {
                    MessageBox.Show("Нет преподавателей в файле.");
                    return;
                }

                var позиции = преподаватели.Select(p => new ПреподавательПозиция(p)).ToList();
                университет = new Университет(позиции);
                DataContext = университет;
            }
        }


        private void btn_save_to_file_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Text files (*.txt)|*.txt|JSON files (*.json)|*.json";

            if (dlg.ShowDialog() == true)
            {
                selectedFilePath = dlg.FileName;

                var преподаватель = new Преподаватель
                {
                    ФИО = FIO.Text,
                    Должность = Dol.Text,
                    Кафедра = myComboBox.Text,
                    Зарплата = decimal.TryParse(ZP.Text.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out var zp) ? zp : 0
                };

                if (Path.GetExtension(selectedFilePath).ToLower() == ".json")
                {
                    List<Преподаватель> currentList = new List<Преподаватель>();

                    if (File.Exists(selectedFilePath))
                    {
                        string jsonOld = File.ReadAllText(selectedFilePath);
                        currentList = JsonConvert.DeserializeObject<List<Преподаватель>>(jsonOld) ?? new List<Преподаватель>();
                    }

                    currentList.Add(преподаватель);
                    string jsonNew = JsonConvert.SerializeObject(currentList, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(selectedFilePath, jsonNew);
                }
                else
                {
                    string строка = $"{преподаватель.ФИО}|{преподаватель.Должность}|{преподаватель.Кафедра}|{преподаватель.Зарплата}";
                    File.AppendAllText(selectedFilePath, строка + "\n");
                }

                MessageBox.Show("Преподаватель сохранен.");
                FIO.Clear(); Dol.Clear(); myComboBox.SelectedIndex = -1; ZP.Clear();
            }
        }


        private void btn_delete_file_Click(object sender, RoutedEventArgs e)
        {
            // Проверка выделенных элементов
            if (MainList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите данные для удаления.",
                               "Предупреждение",
                               MessageBoxButton.OK,
                               MessageBoxImage.Warning);
                return;
            }

            // Подтверждение удаления
            var confirmResult = MessageBox.Show(
                $"Вы точно хотите удалить {MainList.SelectedItems.Count} выбранные данные?\n\n" +
                "Это действие нельзя отменить.",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning,
                MessageBoxResult.No);

            if (confirmResult != MessageBoxResult.Yes)
            {
                MessageBox.Show("Удаление отменено.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Получаем данные и удаляем элементы
            var универ = (Университет)DataContext;
            var itemsToRemove = MainList.SelectedItems.Cast<ПреподавательПозиция>().ToList();

            try
            {
                // Удаление с прогрессом
                int removedCount = 0;
                foreach (var item in itemsToRemove)
                {
                    универ.СписокПреподавателей.Remove(item);
                    removedCount++;
                }

                // Предложение сохранить изменения
                var saveDialogResult = MessageBox.Show(
                    $"Успешно удалено {removedCount} преподавателей.\n\nХотите сохранить изменения?",
                    "Удаление завершено",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (saveDialogResult == MessageBoxResult.Yes)
                {
                    SaveFileDialog sfd = new SaveFileDialog
                    {
                        Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*", // Изменено на txt
                        Title = "Сохранить изменения",
                        FileName = "Преподаватели_обновленные.txt" // Изменено расширение
                    };

                    if (sfd.ShowDialog() == true)
                    {
                        var преподавателиДляСохранения = универ.СписокПреподавателей
                            .Select(p => new Преподаватель
                            {
                                ФИО = p.ФИО,
                                Должность = p.Должность,
                                Кафедра = p.Кафедра,
                                Зарплата = p.Зарплата
                            })
                            .ToList();

                        // Сохраняем в текстовом формате
                        using (StreamWriter writer = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                        {
                            foreach (var преподаватель in преподавателиДляСохранения)
                            {
                                writer.WriteLine($"{преподаватель.ФИО}|{преподаватель.Должность}|{преподаватель.Кафедра}|{преподаватель.Зарплата}");
                            }
                        }

                        MessageBox.Show($"Данные сохранены в файл:\n{sfd.FileName}",
                                      "Сохранено",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Изменения не сохранены.",
                                       "Информация",
                                       MessageBoxButton.OK,
                                       MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }

        private void Kaf_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

