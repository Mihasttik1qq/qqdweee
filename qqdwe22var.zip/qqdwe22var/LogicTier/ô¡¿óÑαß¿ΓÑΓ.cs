﻿using System.Collections.Generic;
using System.Linq;

namespace LogicTier
{
    public class Университет
    {
        private List<ПреподавательПозиция> _преподавателиПозиции;

        public Университет(List<ПреподавательПозиция> позиции)
        {
            _преподавателиПозиции = позиции;
        }

        public List<ПреподавательПозиция> СписокПреподавателей => _преподавателиПозиции;

        public string НаименованиеУниверситета => "Наш университет";

        public int КоличествоПреподавателей => _преподавателиПозиции.Count;

        public Dictionary<string, decimal> СуммаЗарплатПоКафедрам =>
            _преподавателиПозиции
                .GroupBy(p => p.Кафедра)
                .ToDictionary(g => g.Key, g => g.Sum(p => p.Зарплата));
    }
}