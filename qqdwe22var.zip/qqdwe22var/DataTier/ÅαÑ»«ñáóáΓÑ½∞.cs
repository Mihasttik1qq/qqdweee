﻿namespace DataTier
{
    public class Преподаватель
    {
        public string ФИО { get; set; }
        public string Должность { get; set; }
        public string Кафедра { get; set; }
        public decimal Зарплата { get; set; }

        public string ПредставлениеПреподавателя => $"{ФИО} | {Должность} | {Кафедра} | {Зарплата:0.00}₽";
    }
}