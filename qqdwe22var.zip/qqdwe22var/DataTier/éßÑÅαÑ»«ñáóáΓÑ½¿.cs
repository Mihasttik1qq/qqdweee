﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using DataTier;

namespace LogicTier
{
    public static class ВсеПреподаватели
    {
        public static List<Преподаватель> ПолучитьВсеПреподавателиИзФайла(string path)
        {
            List<Преподаватель> list = new List<Преподаватель>();

            using (StreamReader sreader = new StreamReader(path, Encoding.UTF8))
            {
                while (!sreader.EndOfStream)
                {
                    string[] line = sreader.ReadLine().Split('|');
                    if (line.Length < 4) continue;

                    try
                    {
                        var преподаватель = new Преподаватель()
                        {
                            ФИО = line[0].Trim(),
                            Должность = line[1].Trim(),
                            Кафедра = line[2].Trim(),
                            Зарплата = decimal.Parse(line[3].Trim().Replace(',', '.'), CultureInfo.InvariantCulture)
                        };
                        list.Add(преподаватель);
                    }
                    catch
                    {
                        continue;
                    }
                }
            }

            return list;
        }
    }
}